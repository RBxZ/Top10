package com.example.top10_screens;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class view_friend_activity extends AppCompatActivity implements View.OnClickListener {

    TextView title;
    Button back;
    ListView list_view;
    ArrayList<list_class> arrayList;
    List_Adapter list_adapter;
    list_class last;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_friend);

        title = findViewById(R.id.title);
        back = findViewById(R.id.back_btn_friend);

        back.setOnClickListener(this);

        arrayList = new ArrayList<list_class>();

        list_adapter = new List_Adapter(this, 0, 0, arrayList);
        list_view = findViewById(R.id.friend_lists_listview);
        list_view.setAdapter(list_adapter);

        Intent intent = getIntent();
        String friend_name = intent.getExtras().getString("friend_name").toString();
        title.setText(friend_name + "'s Page");
        int size = Integer.parseInt(intent.getExtras().getString("size"));
        int g =0;
        for(int h=0; h<size; h++){
            String current_list_name = "list_name" + String.valueOf(h);
            String current_list_description = "list_description" + String.valueOf(h);
            String list_name = intent.getExtras().getString(current_list_name);
            String list_description = intent.getExtras().getString(current_list_description);
            item_in_list[] items = new item_in_list[10];
            for(int j=0; j<10; j++){
                String current_item_name = "item_name" + String.valueOf(g);
                String current_item_description = "item_description" + String.valueOf(g);
                String current_image = "item_image" + String.valueOf(g);
                String current_format = "format" + String.valueOf(g);
                String item_name = intent.getExtras().getString(current_item_name);
                String item_description = intent.getExtras().getString(current_item_description);
                String format_of_item = intent.getExtras().getString(current_format);
                items[j] = new item_in_list(item_name, item_description, this);
                if(format_of_item.equals("jpg")){
                    items[j].setChanged(true);
                }
                else{
                    items[j].setChanged(false);
                }
                byte[] byteArray = intent.getByteArrayExtra(current_image);
                Bitmap image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                items[j].setImage(image);
                g++;
            }
            list_class list = new list_class(list_name, list_description, items, this);
            list_adapter.add(list);
        }

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                last = list_adapter.getItem(i);
                Intent intent = new Intent(view_friend_activity.this, view_list_activity.class);
                intent.putExtra("purpose", "friend");
                intent.putExtra("list_name", last.getList_name());
                intent.putExtra("list_description", last.getDescription());
                ByteArrayOutputStream bStream2 = new ByteArrayOutputStream();
                Bitmap list_image = last.getImage();
                String list_format = "";
                if(last.isChanged()){
                    list_image.compress(Bitmap.CompressFormat.JPEG, 100, bStream2);
                    list_format = "jpg";
                }
                else{
                    list_image.compress(Bitmap.CompressFormat.PNG, 100, bStream2);
                    list_format = "png";
                }
                byte[] byteArray2 = bStream2.toByteArray();
                intent.putExtra("list_image", byteArray2);
                intent.putExtra("list_format", list_format);
                for(int j=0; j<10; j++){
                    String current_name = "item_name" + String.valueOf(j);
                    String current_description = "item_description" + String.valueOf(j);
                    String current_image = "item_image" + String.valueOf(j);
                    String current_format = "format" + String.valueOf(j);
                    intent.putExtra(current_name, last.getItems()[j].getItem_name());
                    intent.putExtra(current_description, last.getItems()[j].getDescription());
                    ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                    Bitmap bitmap = last.getItems()[j].getImage();
                    String format = "";
                    if(last.getItems()[j].isChanged()){
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bStream);
                        format = "jpg";
                    }
                    else{
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                        format = "png";
                    }
                    byte[] byteArray = bStream.toByteArray();
                    intent.putExtra(current_image, byteArray);
                    intent.putExtra(current_format, format);
                }
                startActivityForResult(intent,0);
            }
        });
    }

    @Override
    public void onClick(View view) {
        if(view == back){
            finish();
        }
    }
}