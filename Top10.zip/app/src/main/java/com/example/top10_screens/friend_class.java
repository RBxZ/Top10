package com.example.top10_screens;

import android.net.Uri;

import java.util.List;

public class friend_class {
    private String name;
    private List<list_class> lists;
    private Uri image;

    public Uri getImage() {
        return image;
    }

    public void setImage(Uri image) {
        this.image = image;
    }

    public List<list_class> getLists() {
        return lists;
    }

    public friend_class(String name, List<list_class> lists) {
        this.name = name;
        this.lists = lists;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public friend_class(String name) {
        this.name = name;
    }
}
