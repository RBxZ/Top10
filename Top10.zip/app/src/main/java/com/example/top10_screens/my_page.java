package com.example.top10_screens;

import static android.app.Activity.RESULT_OK;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

public class my_page extends Fragment implements View.OnClickListener {

    public my_page(){
        // require a empty public constructor
    }

    ListView list_view;
    ArrayList<list_class> arrayList;
    List_Adapter list_adapter;
    list_class last;
    Dialog d;
    Button add_list;
    Socket socket;
    PrintWriter printWriter;
    Client c1;
    int port = 6900;
    ClientThread clientThread;
    private InputStream input;
    String ip ="192.168.11.1";
    android.os.Handler handler;
    String msg;
    list_class last2;
    Button sign_out;
    BottomNavigationView bottomNavigationView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_my_page, container, false);
        inflater.inflate(R.layout.fragment_my_page, container, false);

        add_list = rootView.findViewById(R.id.add_list);
        add_list.setOnClickListener(this);

        sign_out = getActivity().findViewById(R.id.sign_out_btn);
        bottomNavigationView = getActivity().findViewById(R.id.bottom_navigation_view);

        arrayList = new ArrayList<list_class>();

        list_adapter = new List_Adapter(getActivity(), 0, 0, arrayList);
        list_view = rootView.findViewById(R.id.my_page_listview);
        list_view.setAdapter(list_adapter);

        handler = new android.os.Handler(new android.os.Handler.Callback() {
            @Override
            public boolean handleMessage(Message message) {
                String str = (String) message.obj;
                if(str.equals("Failed")){
                    Toast.makeText(getContext(), "No old lists", Toast.LENGTH_LONG).show();

                }
                else{
                    load_lists(str);
                }
                add_list.setEnabled(true);
                sign_out.setEnabled(true);
                bottomNavigationView.setVisibility(View.VISIBLE);
                return false;
            }
        });

        msg = "00013load_my_lists;" + "00004done";
        c1 = new Client();
        c1.execute();
        add_list.setEnabled(false);
        sign_out.setEnabled(false);
        bottomNavigationView.setVisibility(View.INVISIBLE);
        showMessage(rootView, "Loading lists, please be patient...", 15000);

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                last = list_adapter.getItem(i);
                Intent intent = new Intent(getActivity(), view_list_activity.class);
                intent.putExtra("purpose", "my_page");
                intent.putExtra("list_name", last.getList_name());
                intent.putExtra("list_description", last.getDescription());
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                String list_format = "";
                if(last.isChanged()){
                    last.getImage().compress(Bitmap.CompressFormat.JPEG, 20, bStream);
                    list_format = "jpg";
                }
                else{
                    last.getImage().compress(Bitmap.CompressFormat.PNG, 20, bStream);
                    list_format = "png";
                }
                byte[] byteArray = bStream.toByteArray();
                intent.putExtra("list_image", byteArray);
                intent.putExtra("list_format", list_format);
                for(int j=0; j<10; j++){
                        String current_name = "item_name" + String.valueOf(j);
                        String current_description = "item_description" + String.valueOf(j);
                        String current_image = "item_image" + String.valueOf(j);
                        String current_format = "format" + String.valueOf(j);
                        intent.putExtra(current_name, last.getItems()[j].getItem_name());
                        intent.putExtra(current_description, last.getItems()[j].getDescription());
                        ByteArrayOutputStream bStream2 = new ByteArrayOutputStream();
                        Bitmap bitmap = last.getItems()[j].getImage();
                        String format = "";
                        if(last.getItems()[j].isChanged()){
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, bStream2);
                            format = "jpg";
                        }
                        else{
                            bitmap.compress(Bitmap.CompressFormat.PNG, 20, bStream2);
                            format = "png";
                        }
                        byte[] byteArray2 = bStream2.toByteArray();
                        intent.putExtra(current_image, byteArray2);
                        intent.putExtra(current_format, format);
                }
                startActivityForResult(intent,0);
            }
        });
        list_view.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                last = list_adapter.getItem(position);
                handler = new android.os.Handler(new android.os.Handler.Callback() {
                    @Override
                    public boolean handleMessage(Message message) { String str = (String) message.obj;
                        if(str.equals("Deleted")){
                            return true;
                        }
                        return false;
                    }
                });
                createDialog();
                return true;
            }
        });
        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            String name_of_list = data.getExtras().getString("list_name");
            String description_of_list = data.getExtras().getString("list_description");
            last.setList_name(name_of_list);
            last.setDescription(description_of_list);
            byte[] byteArray2 = data.getByteArrayExtra("list_image");
            Bitmap list_image = BitmapFactory.decodeByteArray(byteArray2, 0, byteArray2.length);
            String format_of_list = data.getExtras().getString("list_format");
            if(format_of_list.equals("jpg")){
                last.setChanged(true);
            }
            else{
                last.setChanged(false);
            }
            last.setImage(list_image);
            item_in_list[] items = new item_in_list[10];
            for(int i=0; i<10; i++) {
                String current_name = "item_name" + String.valueOf(i);
                String current_description = "item_description" + String.valueOf(i);
                String current_image = "item_image" + String.valueOf(i);
                String current_format = "format" + String.valueOf(i);
                String name_of_item = data.getExtras().getString(current_name);
                String description_of_item = data.getExtras().getString(current_description);
                String format_of_item = data.getExtras().getString(current_format);
                items[i] = new item_in_list(name_of_item, description_of_item, getContext());
                if(format_of_item.equals("jpg")){
                    items[i].setChanged(true);
                }
                else{
                    items[i].setChanged(false);
                }
                byte[] byteArray = data.getByteArrayExtra(current_image);
                Bitmap image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                items[i].setImage(image);
            }
            last.setItems(items);
            list_adapter.notifyDataSetChanged();
        }
        if (requestCode == 1) {
            if(resultCode==RESULT_OK)
            {
                item_in_list[] items = new item_in_list[10];
                int size = Integer.parseInt(data.getExtras().getString("size"));
                for(int i=0; i<size; i++){
                    String current_name = "item_name" + String.valueOf(i);
                    String current_description = "item_description" + String.valueOf(i);
                    String current_image = "item_image" + String.valueOf(i);
                    String current_format = "format" + String.valueOf(i);
                    String name_of_item = data.getExtras().getString(current_name);
                    String description_of_item = data.getExtras().getString(current_description);
                    String format_of_item = data.getExtras().getString(current_format);
                    items[i] = new item_in_list(name_of_item, description_of_item, getContext());
                    if(format_of_item.equals("jpg")){
                        items[i].setChanged(true);
                    }
                    else{
                        items[i].setChanged(false);
                    }
                    byte[] byteArray = data.getByteArrayExtra(current_image);
                    Bitmap image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                    items[i].setImage(image);
                }
                String name_of_list = data.getExtras().getString("list_name");
                String description_of_list = data.getExtras().getString("list_description");
                byte[] byteArray = data.getByteArrayExtra("list_image");
                Bitmap list_image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                String format_of_list = data.getExtras().getString("list_format");
                list_class list =new list_class(name_of_list, description_of_list, items, getContext());
                if(format_of_list.equals("jpg")){
                    list.setChanged(true);
                }
                else{
                    list.setChanged(false);
                }
                list.setImage(list_image);
                list_adapter.add(list);
                last2 = list;
            }
        }
    }
    public void createDialog() {
        d = new Dialog(getActivity());
        d.setTitle("Are you sure you want to delete this list?");
        d.setContentView(R.layout.delete_list_layout);
        Button cancel = (Button) d.findViewById(R.id.cancel);
        Button delete = (Button) d.findViewById(R.id.delete);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                last = null;
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list_adapter.remove(last);
                list_adapter.notifyDataSetChanged();
                msg = "00011delete_list;" + padWithZeros(last.getList_name().length(), 5) + last.getList_name() + ";" + "00004done";
                c1 = new Client();
                c1.execute();
                d.dismiss();
            }
        });
        d.show();
    }

    @Override
    public void onClick(View view) {
        if(view == add_list){
            Intent intent = new Intent(getActivity(), edit_list_activity.class);
            intent.putExtra("purpose", "add");
            startActivityForResult(intent,1);
        }
    }

    class Client extends AsyncTask {
        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected Boolean doInBackground(Object[] objects) {
            try {
                socket = new Socket(ip, port);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                socket.setReceiveBufferSize(1024);
            } catch (SocketException e) {
                e.printStackTrace();
            }
            try {
                printWriter = new PrintWriter(socket.getOutputStream(), true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                input = socket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            ByteArrayOutputStream availableBytes = new ByteArrayOutputStream();
            try {
                printWriter.write(java.util.Base64.getEncoder().encodeToString(msg.getBytes()));
                printWriter.flush();
                socket.setSoTimeout(14000);
                int i ;
                while((i=input.read())!=-1){
                    availableBytes.write((char)(i));
                }
                String response;
                byte[] buffer = availableBytes.toByteArray();
                String base64_msg = new String(buffer, StandardCharsets.UTF_8);
                byte[] decodedBytes = java.util.Base64.getDecoder().decode(base64_msg);
                response = new String(decodedBytes);
                Message message = new Message();
                message.obj = response;
                boolean check = handler.sendMessage(message);
                return check;
            }
            catch (SocketTimeoutException e){
                String response;
                byte[] buffer = availableBytes.toByteArray();
                String base64_msg = new String(buffer, StandardCharsets.UTF_8);
                byte[] decodedBytes = java.util.Base64.getDecoder().decode(base64_msg);
                response = new String(decodedBytes);
                Message message = new Message();
                message.obj = response;
                boolean check = handler.sendMessage(message);
                return check;
            }
            catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        }

    class ClientThread extends Thread
    {
        @Override
        public void run() {
            try
            {
                socket = new Socket(ip, port);
                socket.setReceiveBufferSize(1024);
                printWriter = new PrintWriter(socket.getOutputStream(), true);
                input = socket.getInputStream();
            }
            catch (UnknownHostException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    private Bitmap myGetBitmap(int drawableRes, Context context) {
        Drawable drawable = context.getResources().getDrawable(drawableRes);
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    public static String padWithZeros(int number, int length) {
        String padded = String.format("%0" + length + "d", number);
        return padded;
    }

    private void showMessage(View view, String message, int duration) {
        // Show the message as a Snackbar
        Snackbar snackbar = Snackbar.make(view, message, duration);
        snackbar.show();
    }

    private void load_lists(String str){
        String[] parameters = str.split(";", 1000);
        int index = 0;
        while(!parameters[index].equals("done") && !parameters[index].equals("don")){
            String list_name = parameters[index];
            String list_description = parameters[index + 1];
            String list_image = parameters[index + 2];
            index += 3;
            item_in_list[] items = new item_in_list[10];
            for(int i = 0; i<10; i++){
                String item_name = parameters[index];
                String item_description = parameters[index + 1];
                String item_image = parameters[index + 2];
                byte[] decodedString = Base64.decode(item_image, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                items[i] = new item_in_list(item_name, item_description, getContext());
                if(item_image.charAt(0) == 'i'){
                    items[i].setChanged(false);
                }
                else{
                    items[i].setChanged(true);
                }
                items[i].setImage(bitmap);
                index += 3;
            }
            list_class list = new list_class(list_name, list_description, items, getContext());
            byte[] decodedString = Base64.decode(list_image, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            list.setImage(bitmap);
            list_adapter.add(list);
        }
    }

}

