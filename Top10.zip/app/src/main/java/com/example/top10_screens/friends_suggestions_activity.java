package com.example.top10_screens;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Node;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class friends_suggestions_activity extends AppCompatActivity implements View.OnClickListener {
    Dialog add_friend_dialog, d;
    ListView list_view;
    ArrayList<friend_class> arrayList;
    friends_adapter friends_adapter;
    friend_class last;
    Button back;
    List<friend_class> friends_to_add = new ArrayList<friend_class>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_suggestions);

        back = findViewById(R.id.back_btn);
        back.setOnClickListener(this);

        arrayList = new ArrayList<friend_class>();

        friends_adapter = new friends_adapter(this, 0, 0, arrayList);
        list_view = findViewById(R.id.suggestions_listview);
        list_view.setAdapter(friends_adapter);

        item_in_list[] items = new item_in_list[10];
        for(int i=0; i<10; i++) {
            String current_name = "item_name" + String.valueOf(i);
            String current_description = "item_description" + String.valueOf(i);
            items[i] = new item_in_list(current_name, current_description, this );
        }
        List<list_class> lists = new ArrayList<list_class>();
        for(int i=0; i<7; i++) {
            String current_name = "list" + String.valueOf(i);
            String current_description = "description" + String.valueOf(i);
            lists.add(new list_class(current_name, current_description, items, this));
        }
        friends_adapter.add(new friend_class("Arbel Oz", lists));
        friends_adapter.add(new friend_class("Arbel Oz2", lists));
        friends_adapter.add(new friend_class("Arbel Oz3", lists));

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                last = friends_adapter.getItem(i);
                createAddFriendDialog(last.getName());
            }
        });

        list_view.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                last = friends_adapter.getItem(position);
                createDeleteDialog();
                return true;
            }
        });
    }
    public void createDeleteDialog() {
        d = new Dialog(this);
        d.setTitle("Are you sure you want to decline this suggestion?");
        d.setContentView(R.layout.delete_friend_layout);
        Button cancel = (Button) d.findViewById(R.id.cancel);
        Button decline = (Button) d.findViewById(R.id.remove);
        TextView title = d.findViewById(R.id.TV_title);
        title.setText("Are you sure you want to decline this suggestion?");
        decline.setText("decline");
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                last = null;
            }
        });
        decline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                friends_adapter.remove(last);
                friends_adapter.notifyDataSetChanged();
                d.dismiss();
            }
        });
        d.show();
    }
    public void createAddFriendDialog(String name) {
        add_friend_dialog = new Dialog(this);
        add_friend_dialog.setContentView(R.layout.delete_friend_layout);
        Button cancel = (Button) add_friend_dialog.findViewById(R.id.cancel);
        Button approve = (Button) add_friend_dialog.findViewById(R.id.remove);
        approve.setText("Approve");
        TextView title = add_friend_dialog.findViewById(R.id.TV_title);
        title.setText("Are you sure you want to approve " + name + " ?");
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add_friend_dialog.dismiss();
                last = null;
            }
        });
        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                friend_class friend_class = new friend_class(last.getName(), last.getLists());
                friends_to_add.add(friend_class);
                friends_adapter.remove(last);
                friends_adapter.notifyDataSetChanged();
                add_friend_dialog.dismiss();
            }
        });
        add_friend_dialog.show();
    }

    @Override
    public void onClick(View view) {
        if(view == back){
            Intent intent = new Intent();
            if(friends_to_add.size() == 0){
                setResult(RESULT_CANCELED, intent);
                finish();
            }
            else{
                int g = 0;
                int r = 0;
                intent.putExtra("friends_count", String.valueOf(friends_to_add.size()));
                int length = friends_to_add.size();
                for(int i = 0; i<length; i++){
                    friend_class friend_class = friends_to_add.get(i);
                    String current_friend_name = "friend_name" + String.valueOf(i);
                    String current_size = "size" + String.valueOf(i);
                    intent.putExtra(current_friend_name, friend_class.getName());
                    intent.putExtra(current_size, String.valueOf(friend_class.getLists().size()));
                    for(int h=0; h<friend_class.getLists().size(); h++){
                        String current_list_name = "list_name" + String.valueOf(r);
                        String current_list_description = "list_description" + String.valueOf(r);
                        intent.putExtra(current_list_name, friend_class.getLists().get(h).getList_name());
                        intent.putExtra(current_list_description, friend_class.getLists().get(h).getDescription());
                        r++;
                        for(int j=0; j<10; j++) {
                            String current_item_name = "item_name" + String.valueOf(g);
                            String current_item_description = "item_description" + String.valueOf(g);
                            intent.putExtra(current_item_name, friend_class.getLists().get(h).getItems()[j].getItem_name());
                            intent.putExtra(current_item_description, friend_class.getLists().get(h).getItems()[j].getDescription());
                            g++;
                        }
                    }
                }
                setResult(RESULT_OK, intent);
                finish();
            }
        }
    }
}