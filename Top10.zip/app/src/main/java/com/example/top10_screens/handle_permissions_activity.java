package com.example.top10_screens;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

public class handle_permissions_activity extends AppCompatActivity implements View.OnClickListener{

    Button back;
    Button gallery_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_handle_permissions);

        back = findViewById(R.id.back_btn);
        gallery_button = findViewById(R.id.handle_gallery_btn);

        back.setOnClickListener(this);
        gallery_button.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if(view == back){
            finish();
        }
        else if (view == gallery_button){
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "Permission was already granted, you can cancel in settings", Toast.LENGTH_LONG).show();
            }
            else{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        return;
    }
}