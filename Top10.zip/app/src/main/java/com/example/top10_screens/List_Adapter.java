package com.example.top10_screens;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class List_Adapter extends ArrayAdapter<list_class> {

    Context context;
    List<list_class> objects;

    public List_Adapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<list_class> objects) {
        super(context, resource, textViewResourceId, objects);
        this.objects = objects;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.list_layout, parent, false);

        ImageView ivList = (ImageView) view.findViewById(R.id.list_image);
        TextView tvTitle = (TextView) view.findViewById(R.id.list_name);
        TextView tvDescription = (TextView) view.findViewById(R.id.list_description);
        list_class temp = objects.get(position);

        ivList.setImageBitmap(temp.getImage());
        tvTitle.setText(String.valueOf(temp.getList_name()));
        tvDescription.setText(temp.getDescription());

        return view;
    }
}
