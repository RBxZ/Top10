package com.example.top10_screens;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class edit_user_details_activity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    Button cancel, save;
    EditText username, password;
    ImageView image;
    Uri selectedImageUri;
    Bitmap bitmap;
    Socket socket;
    PrintWriter printWriter;
    Client c1;
    int port = 6900;
    ClientThread clientThread;
    private InputStream input;
    String ip ="192.168.11.1";
    android.os.Handler handler;
    String username_str, password_str;
    String msg;
    Boolean isChanged = false;
    Dialog d;
    Boolean isDeleted = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user_details);

        cancel = findViewById(R.id.cancel_edit_account_btn);
        save = findViewById(R.id.save_account_btn);
        username = findViewById(R.id.username_et);
        password = findViewById(R.id.password_et);
        image = findViewById(R.id.user_image);


        save.setOnClickListener(this);
        cancel.setOnClickListener(this);
        image.setOnClickListener(this);
        image.setOnLongClickListener(this);

        clientThread = new ClientThread();
        clientThread.start();
        handler = new android.os.Handler(new android.os.Handler.Callback() {
            @Override
            public boolean handleMessage(Message message) { String str = (String) message.obj;
                if (str.equals("Failed")){
                    Toast.makeText(edit_user_details_activity.this, "Username already exists", Toast.LENGTH_LONG).show();
                    return false;
                }
                else if(str.equals("Success")){
                    finish();
                }
                return true;
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (view == cancel){
            msg = "00004done";
            c1 = new Client();
            c1.start();
            finish();
        }
        if(view == save){
            if(password.getText().toString().isEmpty() || username.getText().toString().isEmpty()){
                Toast.makeText(this, "Please feel all fields", Toast.LENGTH_LONG).show();
            }
            else{
                username_str = username.getText().toString();
                password_str = password.getText().toString();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                if(isChanged){
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream .toByteArray();
                    String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
                    msg = "00009edit_user" + ";" + padWithZeros(username_str.length(), 5) + username_str + ";" + padWithZeros(password_str.length(), 5) + password_str + ";" + padWithZeros(encoded.length(), 5) + encoded + ";" + "00004done";
                }
                else if(isDeleted){
                    bitmap.compress(Bitmap.CompressFormat.PNG, 50, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream .toByteArray();
                    String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
                    msg = "00009edit_user" + ";" + padWithZeros(username_str.length(), 5) + username_str + ";" + padWithZeros(password_str.length(), 5) + password_str + ";" + padWithZeros(encoded.length(), 5) + encoded + ";" + "00004done";
                }
                else{
                    msg = "00009edit_user" + ";" + padWithZeros(username_str.length(), 5) + username_str + ";" + padWithZeros(password_str.length(), 5) + password_str + "00006false;" + "00004done";
                }
                c1 = new Client();
                c1.start();
            }
        }
        if (view == image){
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Select Picture"), 1);
            }
            else{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 0){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Select Picture"), 1);
            }
            else {
                Toast.makeText(this, "Permission denied, you can change it in the settings tab", Toast.LENGTH_LONG).show();
            }
            return;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    try {
                        bitmap =  MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                        image.setImageBitmap(bitmap);
                        isChanged = true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public boolean onLongClick(View view) {
        if(view == image){
            createDeleteDialog();
        }
        return true;
    }

    public void createDeleteDialog() {
        d = new Dialog(this);
        d.setTitle("Are you sure you want to delete this image?");
        d.setContentView(R.layout.delete_friend_layout);
        TextView title = d.findViewById(R.id.TV_title);
        Button cancel = (Button) d.findViewById(R.id.cancel);
        Button delete = (Button) d.findViewById(R.id.remove);
        title.setText("Are you sure you want to delete this image?");
        delete.setText("Delete");
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setImageBitmap(MygetBitmap(R.drawable.default_user_image, edit_user_details_activity.this));
                bitmap = MygetBitmap(R.drawable.default_user_image, edit_user_details_activity.this);
                selectedImageUri = null;
                isDeleted = true;
                isChanged = false;
                d.dismiss();
            }
        });
        d.show();
    }

    class Client extends Thread {
        @RequiresApi(api = Build.VERSION_CODES.O)
        public void run()
        {
            try{
                printWriter.write(java.util.Base64.getEncoder().encodeToString(msg.getBytes()));
                printWriter.flush();
                int lockSeconds = 20 * 1000;
                long lockThreadCheckpoint = System.currentTimeMillis();
                int availableBytes = input.available();
                while (availableBytes <=0 && (System.currentTimeMillis() < lockThreadCheckpoint + lockSeconds)){
                    try
                    {
                        Thread.sleep(10);
                    }
                    catch(InterruptedException ie)
                    {
                        ie.printStackTrace();
                    }
                    availableBytes = input.available(); }
                String response;
                byte[] buffer = new byte[availableBytes];
                input.read(buffer, 0, availableBytes);
                String base64_msg = new String(buffer, StandardCharsets.UTF_8);
                byte[] decodedBytes = java.util.Base64.getDecoder().decode(base64_msg);
                response = new String(decodedBytes);
                Message message = new Message();
                message.obj = response;
                handler.sendMessage(message);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class ClientThread extends Thread
    {
        @Override
        public void run() {
            try
            {
                socket = new Socket(ip, port);
                socket.setReceiveBufferSize(1024);
                printWriter = new PrintWriter(socket.getOutputStream(), true);
                input = socket.getInputStream();
            }
            catch (UnknownHostException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static String padWithZeros(int number, int length) {
        String padded = String.format("%0" + length + "d", number);
        return padded;
    }

    private Bitmap MygetBitmap(int drawableRes, Context context) {
        Drawable drawable = context.getResources().getDrawable(drawableRes);
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }
}