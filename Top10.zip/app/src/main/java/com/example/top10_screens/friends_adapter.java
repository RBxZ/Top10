package com.example.top10_screens;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class friends_adapter extends ArrayAdapter<friend_class> {
    Context context;
    List<friend_class> objects;

    public friends_adapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<friend_class> objects) {
        super(context, resource, textViewResourceId, objects);
        this.objects = objects;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.friend_layout, parent, false);

        ImageView ivFriend = (ImageView) view.findViewById(R.id.friend_image);
        TextView tvName = (TextView) view.findViewById(R.id.friend_name);
        friend_class temp = objects.get(position);

        tvName.setText(String.valueOf(temp.getName()));
        return view;
    }
}
