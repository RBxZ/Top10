package com.example.top10_screens;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class Log_In_screen extends AppCompatActivity implements View.OnClickListener {

    Button cancel, submit;
    EditText username, password;
    Socket socket;
    PrintWriter printWriter;
    Client c1;
    int port = 6900;
    ClientThread clientThread;
    private InputStream input;
    String ip ="192.168.11.1";
    android.os.Handler handler;
    String username_str, password_str;
    String msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_screen);

        submit = findViewById(R.id.submit_account_btn);
        cancel = findViewById(R.id.cancel_account_btn);
        submit.setOnClickListener(this);
        cancel.setOnClickListener(this);
        password = findViewById(R.id.password_et);
        username = findViewById(R.id.username_et);

        clientThread = new ClientThread();
        clientThread.start();
        handler = new android.os.Handler(new android.os.Handler.Callback() {
            @Override
            public boolean handleMessage(Message message) { String str = (String) message.obj;
                if (str.equals("Failed")){
                    Toast.makeText(Log_In_screen.this, "Wrong username or password", Toast.LENGTH_LONG).show();
                    return false;
                }
                else if(str.equals("Success")){
                    Intent intent = new Intent(Log_In_screen.this, navigation_screen.class);
                    startActivity(intent);
                    finish();
                }
                return true;
            }
        });
    }

    @Override
    public void onClick(View view) {
        if(view == cancel) {
            msg = "00004done";
            c1 = new Client();
            c1.start();
            finish();
        }
        else if (view == submit){
            if(password.getText().toString().isEmpty() || username.getText().toString().isEmpty()){
                Toast.makeText(this, "Please feel all fields", Toast.LENGTH_LONG).show();
            }
            else{
                //Validate user
                username_str = username.getText().toString();
                password_str = password.getText().toString();
                username_str = String.valueOf(username_str.length()) + username_str;
                password_str = String.valueOf(password_str.length()) + password_str;
                msg = "00006log_in" + ";" + "0000" + username_str + ";" + "0000" + password_str + ";" + "00004done";
                c1 = new Client();
                c1.start();
            }
        }
    }

    class Client extends Thread {
        @RequiresApi(api = Build.VERSION_CODES.O)
        public void run()
        {
            try{
                printWriter.write(java.util.Base64.getEncoder().encodeToString(msg.getBytes()));
                printWriter.flush();
                int lockSeconds = 20 * 1000;
                long lockThreadCheckpoint = System.currentTimeMillis();
                int availableBytes = input.available();
                while (availableBytes <=0 && (System.currentTimeMillis() < lockThreadCheckpoint + lockSeconds)){
                    try
                    {
                        Thread.sleep(10);
                    }
                    catch(InterruptedException ie)
                    {
                        ie.printStackTrace();
                    }
                    availableBytes = input.available(); }
                String response;
                byte[] buffer = new byte[availableBytes];
                input.read(buffer, 0, availableBytes);
                String base64_msg = new String(buffer, StandardCharsets.UTF_8);
                byte[] decodedBytes = java.util.Base64.getDecoder().decode(base64_msg);
                response = new String(decodedBytes);
                Message message = new Message();
                message.obj = response;
                handler.sendMessage(message);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class ClientThread extends Thread
    {
        @Override
        public void run() {
            try
            {
                socket = new Socket(ip, port);
                socket.setReceiveBufferSize(1024);
                printWriter = new PrintWriter(socket.getOutputStream(), true);
                input = socket.getInputStream();
            }
            catch (UnknownHostException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
}