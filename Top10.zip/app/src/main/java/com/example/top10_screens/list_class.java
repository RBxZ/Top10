package com.example.top10_screens;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

public class list_class {
    private String list_name;
    private String description;
    private item_in_list[] items;
    private Bitmap image;
    private Context context;
    private boolean changed;

    public boolean isChanged() {
        return changed;
    }

    public void setChanged(boolean changed) {
        this.changed = changed;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public void setItems(item_in_list[] items) {
        this.items = items;
    }

    public item_in_list[] getItems() {
        return items;
    }

    public list_class(String list_name, String description, item_in_list[] items, Context context) {
        this.list_name = list_name;
        this.description = description;
        this.items = new item_in_list[10];
        for(int i =0; i<10; i++){
            this.items[i] = items[i];
        }
        this.context = context;
        this.image = getBitmap(R.drawable.default_list_image, context);
        this.changed = false;
    }

    public String getList_name() {
        return list_name;
    }

    public void setList_name(String list_name) {
        this.list_name = list_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    private Bitmap getBitmap(int drawableRes, Context context) {
        Drawable drawable = context.getResources().getDrawable(drawableRes);
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }
}
