package com.example.top10_screens;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class view_comments extends AppCompatActivity implements View.OnClickListener {

    Button back, add_comment;
    ListView list_view;
    ArrayList<comment_class> arrayList;
    comment_adapter comment_adapter;
    comment_class last;
    Dialog add_comment_dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_comments);

        back = findViewById(R.id.back_btn);
        back.setOnClickListener(this);

        add_comment = findViewById(R.id.add_comment_btn);
        if(getIntent().getExtras().getString("purpose").equals("view")){
            add_comment.setVisibility(View.INVISIBLE);
            add_comment.setClickable(false);
        }
        else{
            add_comment.setOnClickListener(this);
        }

        arrayList = new ArrayList<comment_class>();

        arrayList.add(new comment_class("arbel", "oz"));
        arrayList.add(new comment_class("arbel", "oz"));
        arrayList.add(new comment_class("arbel", "oz"));

        comment_adapter = new comment_adapter(this, 0, 0, arrayList);
        list_view = findViewById(R.id.comments_listview);
        list_view.setAdapter(comment_adapter);

    }

    public void createAddCommentDialog() {
        add_comment_dialog = new Dialog(this);
        add_comment_dialog.setContentView(R.layout.add_comment_layout);
        Button cancel = (Button) add_comment_dialog.findViewById(R.id.cancel_comment_btn);
        Button add = (Button) add_comment_dialog.findViewById(R.id.add_comment_btn);
        EditText title = add_comment_dialog.findViewById(R.id.ET_comment_title);
        EditText content = add_comment_dialog.findViewById(R.id.ET_comment_content);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add_comment_dialog.dismiss();
                last = null;
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!title.getText().toString().isEmpty() && !content.getText().toString().isEmpty()){
                    comment_adapter.add(new comment_class(title.getText().toString(), content.getText().toString()));
                    add_comment_dialog.dismiss();
                }
                else{
                    Toast.makeText(view_comments.this, "Please enter title and content", Toast.LENGTH_LONG).show();
                }
            }
        });
        add_comment_dialog.show();
    }

    @Override
    public void onClick(View view) {
        if(view == back){
            finish();
        }
        else if(view == add_comment){
            createAddCommentDialog();
        }
    }


}