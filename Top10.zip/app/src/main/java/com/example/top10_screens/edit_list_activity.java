package com.example.top10_screens;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.InputStream;
import java.io.PrintWriter;
import java.lang.String;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class edit_list_activity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {
    EditText list_name, list_description;
    Button save, cancel;
    ImageView list_image;
    ListView list_view;
    ArrayList<item_in_list> arrayList;
    ItemsAdapter itemsAdapter;
    item_in_list last;
    boolean[] changed = new boolean[10];
    Bitmap bitmap;
    Uri selectedImageUri;
    boolean list_image_changed = false;
    Dialog d;
    Socket socket;
    PrintWriter printWriter;
    Client c1;
    int port = 6900;
    ClientThread clientThread;
    private InputStream input;
    String ip ="192.168.11.1";
    android.os.Handler handler;
    String msg;
    String purpose;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_list);


        list_name = (EditText) findViewById(R.id.ET_list_name);
        list_description = (EditText) findViewById(R.id.ET_description);
        save = (Button) findViewById(R.id.save_list_btn);
        cancel = (Button) findViewById(R.id.cancel_edit_list_btn);
        save.setOnClickListener(this);
        cancel.setOnClickListener(this);
        list_image = (ImageView) findViewById(R.id.list_image);

        list_image.setOnClickListener(this);
        list_image.setOnLongClickListener(this);

        arrayList = new ArrayList<item_in_list>();

        Intent intent = getIntent();
        if(intent.getStringExtra("purpose").equals("edit")){
            purpose = "edit";
            String name_of_list = intent.getStringExtra("list_name");
            name = name_of_list;
            String description_of_list = intent.getStringExtra("list_description");
            list_name.setText(name_of_list);
            list_description.setText(description_of_list);
            byte[] byteArray2 = intent.getByteArrayExtra("list_image");
            Bitmap image_of_list = BitmapFactory.decodeByteArray(byteArray2, 0, byteArray2.length);
            bitmap = image_of_list;
            String list_format = intent.getExtras().getString("list_format");
            if(list_format.equals("jpg")){
                list_image_changed = true;
            }
            else{
                list_image_changed = false;
            }
            list_image.setImageBitmap(image_of_list);
            int size = Integer.parseInt(intent.getStringExtra("size"));
            for(int i=0; i<size; i++){
                String current_name = "item_name" + String.valueOf(i);
                String current_description = "item_description" + String.valueOf(i);
                String current_image = "item_image" + String.valueOf(i);
                String current_format = "format" + String.valueOf(i);
                String name_of_item = intent.getStringExtra(current_name);
                String description_of_item = intent.getStringExtra(current_description);
                String format_of_item = intent.getExtras().getString(current_format);
                item_in_list item = new item_in_list(name_of_item, description_of_item, this);
                if(format_of_item.equals("jpg")){
                    item.setChanged(true);
                    changed[i] = true;
                }
                else{
                    item.setChanged(false);
                    changed[i] = false;
                }
                byte[] byteArray = intent.getByteArrayExtra(current_image);
                Bitmap image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                item.setImage(image);
                arrayList.add(item);
            }
        }
        else{
            purpose = "add";
            list_name.setText("list_name");
            list_description.setText("list_description");
            list_image.setImageBitmap(getBitmap(R.drawable.default_list_image, this));
            bitmap = getBitmap(R.drawable.default_list_image, this);
            for(int i=0; i<10; i++){
                String current_name = "item_name" + String.valueOf(i);
                String current_description = "item_description" + String.valueOf(i);
                arrayList.add(new item_in_list(current_name, current_description, this));
            }
        }

        itemsAdapter = new ItemsAdapter(this, 0, 0, arrayList);
        list_view = findViewById(R.id.edit_listview);
        list_view.setAdapter(itemsAdapter);

        clientThread = new ClientThread();
        clientThread.start();
        handler = new android.os.Handler(new android.os.Handler.Callback() {
            @Override
            public boolean handleMessage(Message message) {
                String str = (String) message.obj;
                if (str.equals("Success")) {
                    if (list_name.getText().toString().length() > 0 && list_description.getText().toString().length() > 0) {
                        Intent intent = getIntent();
                        int size = itemsAdapter.getCount();
                        intent.putExtra("size", String.valueOf(size));
                        intent.putExtra("list_name", list_name.getText().toString());
                        intent.putExtra("list_description", list_description.getText().toString());
                        ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                        String list_format = "";
                        if (list_image_changed) {
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, bStream);
                            list_format = "jpg";
                        } else {
                            bitmap.compress(Bitmap.CompressFormat.PNG, 20, bStream);
                            list_format = "png";
                        }
                        byte[] byteArray = bStream.toByteArray();
                        intent.putExtra("list_image", byteArray);
                        intent.putExtra("list_format", list_format);
                        for (int i = 0; i < size; i++) {
                            String current_name = "item_name" + String.valueOf(i);
                            String current_description = "item_description" + String.valueOf(i);
                            String current_image = "item_image" + String.valueOf(i);
                            String current_format = "format" + String.valueOf(i);
                            intent.putExtra(current_name, itemsAdapter.getItem(i).getItem_name());
                            intent.putExtra(current_description, itemsAdapter.getItem(i).getDescription());
                            ByteArrayOutputStream bStream2 = new ByteArrayOutputStream();
                            Bitmap bitmap2 = itemsAdapter.getItem(i).getImage();
                            String format = "";
                            if (changed[i]) {
                                bitmap2.compress(Bitmap.CompressFormat.JPEG, 20, bStream2);
                                format = "jpg";
                            } else {
                                bitmap2.compress(Bitmap.CompressFormat.PNG, 20, bStream2);
                                format = "png";
                            }
                            byte[] byteArray2 = bStream2.toByteArray();
                            intent.putExtra(current_image, byteArray2);
                            intent.putExtra(current_format, format);
                        }
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                    return true;
                } else if (str.equals("Failed")) {
                    Toast.makeText(edit_list_activity.this, "List name already exists", Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                last = itemsAdapter.getItem(i);
                Intent intent = new Intent(edit_list_activity.this, edit_item_activity.class);
                intent.putExtra("item_name", last.getItem_name());
                intent.putExtra("description", last.getDescription());
                intent.putExtra("position", String.valueOf(i));
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                Bitmap bitmap = last.getImage();
                if(changed[i]){
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bStream);
                }
                else{
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                }
                byte[] byteArray = bStream.toByteArray();
                intent.putExtra("image", byteArray);

                startActivityForResult(intent,0);
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (save == view)//option 2 - save the data and go to first screen
        {
            if (list_name.getText().toString().length() > 0 && list_description.getText().toString().length() > 0) {
                String goal = purpose + "_my_list";
                msg = padWithZeros(goal.length(), 5) + goal + ";";
                if(purpose.equals("edit")){
                    msg = msg + padWithZeros(name.length(), 5) + name + ";";
                }
                msg  = msg + padWithZeros(list_name.getText().toString().length(), 5) + list_name.getText().toString() + ";" + padWithZeros(list_description.getText().toString().length(), 5) + list_description.getText().toString() + ";";
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                if(list_image_changed){
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 20, bStream);
                }
                else{
                    bitmap.compress(Bitmap.CompressFormat.PNG, 20, bStream);
                }
                byte[] byteArray = bStream.toByteArray();
                String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
                msg = msg + padWithZeros(encoded.length(), 5) + encoded + ";";
                String all_items = "";
                for(int i=0; i<10; i++){
                    all_items = all_items + padWithZeros(itemsAdapter.getItem(i).getItem_name().length(), 5) + itemsAdapter.getItem(i).getItem_name() + ";" + padWithZeros(itemsAdapter.getItem(i).getDescription().length(), 5) + itemsAdapter.getItem(i).getDescription() + ";";
                    ByteArrayOutputStream bStream2 = new ByteArrayOutputStream();
                    Bitmap bitmap2 = itemsAdapter.getItem(i).getImage();
                    if(changed[i]){
                        bitmap2.compress(Bitmap.CompressFormat.JPEG, 20, bStream2);
                    }
                    else{
                        bitmap2.compress(Bitmap.CompressFormat.PNG, 20, bStream2);
                    }
                    byte[] byteArray2 = bStream2.toByteArray();
                    String encoded2 = Base64.encodeToString(byteArray2, Base64.DEFAULT);
                    all_items = all_items + padWithZeros(encoded2.length(), 5) + encoded2 + ";";
                }
                msg = msg + all_items;
                msg = msg + "00004done";
                c1 = new Client();
                c1.start();
            }
        } else if (cancel == view) {
            setResult(RESULT_CANCELED, null);
            finish();
        }
        else if(view == list_image){
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Select Picture"), 1);
            }
            else{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 0){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Select Picture"), 1);
            }
            else {
                Toast.makeText(this, "Permission denied, you can change it in the settings tab", Toast.LENGTH_LONG).show();
            }
            return;
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==0)
        {
            if(resultCode==RESULT_OK)
            {
                int position = Integer.parseInt(data.getExtras().getString("position"));
                String name = data.getExtras().getString("item_name");
                String description = data.getExtras().getString("description");
                if(data.getExtras().getString("image").equals("deleted")){
                    last.setImage(getBitmap(R.drawable.default_item_image, this));
                    changed[position] = false;
                }
                else if(!data.getExtras().getString("image").equals("not changed")){
                    Uri uri = Uri.parse(data.getExtras().getString("image"));
                    changed[position] = true;
                    Bitmap bmp = null;
                    try {
                        bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                        last.setImage(bmp);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                last.setItem_name(name);
                last.setDescription(description);
                itemsAdapter.notifyDataSetChanged();
            }
        }
        if (requestCode == 1) {
            selectedImageUri = data.getData();
            if (null != selectedImageUri) {
                try {
                    bitmap =  MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                    list_image.setImageBitmap(bitmap);
                    list_image_changed = true;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
    private Bitmap getBitmap(int drawableRes, Context context) {
        Drawable drawable = context.getResources().getDrawable(drawableRes);
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    @Override
    public boolean onLongClick(View view) {
        if(view == list_image){
            createDeleteDialog();
        }
        return true;
    }

    public void createDeleteDialog() {
        d = new Dialog(this);
        d.setTitle("Are you sure you want to delete this image?");
        d.setContentView(R.layout.delete_friend_layout);
        TextView title = d.findViewById(R.id.TV_title);
        Button cancel = (Button) d.findViewById(R.id.cancel);
        Button delete = (Button) d.findViewById(R.id.remove);
        title.setText("Are you sure you want to delete this image?");
        delete.setText("Delete");
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list_image.setImageBitmap(getBitmap(R.drawable.default_list_image, edit_list_activity.this));
                bitmap = getBitmap(R.drawable.default_list_image, edit_list_activity.this);
                selectedImageUri = null;
                list_image_changed = false;
                d.dismiss();
            }
        });
        d.show();
    }

    class Client extends Thread {
        @RequiresApi(api = Build.VERSION_CODES.O)
        public void run()
        {
            try {
                printWriter.write(java.util.Base64.getEncoder().encodeToString(msg.getBytes()));
                printWriter.flush();
                int lockSeconds = 20 * 1000;
                long lockThreadCheckpoint = System.currentTimeMillis();
                int availableBytes = input.available();
                while (availableBytes <= 0 && (System.currentTimeMillis() < lockThreadCheckpoint + lockSeconds)) {
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException ie) {
                        ie.printStackTrace();
                    }
                    availableBytes = input.available();
                }
                String response;
                byte[] buffer = new byte[availableBytes];
                input.read(buffer, 0, availableBytes);
                String base64_msg = new String(buffer, StandardCharsets.UTF_8);
                byte[] decodedBytes = java.util.Base64.getDecoder().decode(base64_msg);
                response = new String(decodedBytes);
                Message message = new Message();
                message.obj = response;
                boolean check = handler.sendMessage(message);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class ClientThread extends Thread
    {
        @Override
        public void run() {
            try
            {
                socket = new Socket(ip, port);
                socket.setReceiveBufferSize(1024);
                printWriter = new PrintWriter(socket.getOutputStream(), true);
                input = socket.getInputStream();
            }
            catch (UnknownHostException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    private Bitmap myGetBitmap(int drawableRes, Context context) {
        Drawable drawable = context.getResources().getDrawable(drawableRes);
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    public static String padWithZeros(int number, int length) {
        String padded = String.format("%0" + length + "d", number);
        return padded;
    }
}
