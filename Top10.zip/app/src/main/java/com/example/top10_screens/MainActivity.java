package com.example.top10_screens;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button sign_in, log_in;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sign_in = findViewById(R.id.sign_in_btn);
        log_in = findViewById(R.id.log_in_btn);
        sign_in.setOnClickListener(this);
        log_in.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == sign_in){
            Intent switchActivityIntent = new Intent(this, sign_in_screen.class);
            startActivity(switchActivityIntent);
        }

        else if(view == log_in){
            Intent switchActivityIntent = new Intent(this, Log_In_screen.class);
            startActivity(switchActivityIntent);
        }

    }
}