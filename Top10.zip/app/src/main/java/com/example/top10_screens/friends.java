package com.example.top10_screens;

import static android.app.Activity.RESULT_OK;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.top10_screens.R;

public class friends extends Fragment implements View.OnClickListener {

    public friends(){
        // require a empty public constructor
    }

    ListView list_view;
    ArrayList<friend_class> arrayList;
    friends_adapter friends_adapter;
    friend_class last;
    Dialog add_friend_dialog, d;
    Button add_friend, friends_suggestions;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_friends, container, false);
        inflater.inflate(R.layout.fragment_friends, container, false);

        add_friend = rootView.findViewById(R.id.add_friend);
        friends_suggestions =rootView.findViewById(R.id.friend_suggestions_btn);
        friends_suggestions.setOnClickListener(this);
        add_friend.setOnClickListener(this);

        arrayList = new ArrayList<friend_class>();

        friends_adapter = new friends_adapter(getActivity(), 0, 0, arrayList);
        list_view = rootView.findViewById(R.id.friends_listview);
        list_view.setAdapter(friends_adapter);

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                last = friends_adapter.getItem(i);
                Intent intent = new Intent(getActivity(), view_friend_activity.class);
                intent.putExtra("friend_name", last.getName());
                intent.putExtra("size", String.valueOf(last.getLists().size()));
                int g = 0;
                for(int h=0; h<last.getLists().size(); h++){
                    String current_list_name = "list_name" + String.valueOf(h);
                    String current_list_description = "list_description" + String.valueOf(h);
                    intent.putExtra(current_list_name, last.getLists().get(h).getList_name());
                    intent.putExtra(current_list_description, last.getLists().get(h).getDescription());
                    for(int j=0; j<10; j++) {
                        String current_item_name = "item_name" + String.valueOf(g);
                        String current_item_description = "item_description" + String.valueOf(g);
                        String current_image = "item_image" + String.valueOf(g);
                        String current_format = "format" + String.valueOf(g);
                        intent.putExtra(current_item_name, last.getLists().get(h).getItems()[j].getItem_name());
                        intent.putExtra(current_item_description, last.getLists().get(h).getItems()[j].getDescription());
                        ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                        Bitmap bitmap = last.getLists().get(h).getItems()[j].getImage();
                        String format = "";
                        if(last.getLists().get(h).getItems()[j].isChanged()){
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bStream);
                            format = "jpg";
                        }
                        else{
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                            format = "png";
                        }
                        byte[] byteArray = bStream.toByteArray();
                        intent.putExtra(current_image, byteArray);
                        intent.putExtra(current_format, format);
                        g++;
                    }
                }
                startActivityForResult(intent,0);
            }
        });

        list_view.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                last = friends_adapter.getItem(position);
                createDeleteDialog();
                return true;
            }
        });
        return rootView;
    }
    public void createDeleteDialog() {
        d = new Dialog(getActivity());
        d.setTitle("Are you sure you want to remove this friend?");
        d.setContentView(R.layout.delete_friend_layout);
        Button cancel = (Button) d.findViewById(R.id.cancel);
        Button remove = (Button) d.findViewById(R.id.remove);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                last = null;
            }
        });
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                friends_adapter.remove(last);
                friends_adapter.notifyDataSetChanged();
                d.dismiss();
            }
        });
        d.show();
    }
    public void createAddFriendDialog() {
        add_friend_dialog = new Dialog(getActivity());
        add_friend_dialog.setContentView(R.layout.add_friend_layout);
        Button cancel = (Button) add_friend_dialog.findViewById(R.id.cancel);
        Button add = (Button) add_friend_dialog.findViewById(R.id.add);
        EditText name_of_friend = add_friend_dialog.findViewById(R.id.ET_friend_add);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add_friend_dialog.dismiss();
                last = null;
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!name_of_friend.getText().toString().isEmpty()){
                    item_in_list[] items = new item_in_list[10];
                    for(int i=0; i<10; i++) {
                        String current_name = "item_name" + String.valueOf(i);
                        String current_description = "item_description" + String.valueOf(i);
                        items[i] = new item_in_list(current_name, current_description, getContext());
                    }
                    List<list_class> lists = new ArrayList<list_class>();
                    for(int i=0; i<7; i++) {
                        String current_name = "list" + String.valueOf(i);
                        String current_description = "description" + String.valueOf(i);
                        lists.add(new list_class(current_name, current_description, items, getContext()));
                    }
                    friends_adapter.add(new friend_class(name_of_friend.getText().toString(), lists));
                    add_friend_dialog.dismiss();
                }
                else{
                    Toast.makeText(getActivity(), "Please enter a name to add", Toast.LENGTH_LONG).show();
                }
            }
        });
        add_friend_dialog.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            if(resultCode==RESULT_OK){
                Intent intent = new Intent();
                int g = 0;
                int r = 0;
                int number_of_friends = Integer.parseInt(data.getExtras().getString("friends_count"));
                for(int i = 0; i<number_of_friends; i++){
                    String current_friend_name = "friend_name" + String.valueOf(i);
                    String current_size = "size" + String.valueOf(i);
                    String name_of_friend = data.getExtras().getString(current_friend_name);
                    int number_of_lists = Integer.parseInt(data.getExtras().getString(current_size));
                    List<list_class> lists = new ArrayList<list_class>();
                    for(int h=0; h<number_of_lists; h++){
                        String current_list_name = "list_name" + String.valueOf(r);
                        String current_list_description = "list_description" + String.valueOf(r);
                        String name_of_list = data.getExtras().getString(current_list_name);
                        String description_of_list = data.getExtras().getString(current_list_description);
                        r++;
                        item_in_list[] items = new item_in_list[10];
                        for(int j=0; j<10; j++) {
                            String current_item_name = "item_name" + String.valueOf(g);
                            String current_item_description = "item_description" + String.valueOf(g);
                            String name_of_item = data.getExtras().getString(current_item_name);
                            String description_of_item = data.getExtras().getString(current_item_description);
                            g++;
                            items[j] = new item_in_list(name_of_item, description_of_item, getContext());
                        }
                        list_class list_class = new list_class(name_of_list, description_of_list, items, getContext());
                        lists.add(list_class);
                    }
                    friend_class friend_class = new friend_class(name_of_friend, lists);
                    friends_adapter.add(friend_class);
                }
            }
        }
    }

    @Override
    public void onClick(View view) {
        if(view == add_friend){
            createAddFriendDialog();
        }
        else if(view == friends_suggestions){
            Intent intent = new Intent(getActivity(), friends_suggestions_activity.class);
            startActivityForResult(intent, 0);
        }
    }
}