package com.example.top10_screens;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class edit_item_activity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    Button save, cancel;
    EditText item_name, item_description;
    ImageView item_image;
    Uri selectedImageUri;
    Bitmap bitmap;
    Bitmap image;
    int position;
    Dialog d;
    String message;
    boolean deleted = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        save = findViewById(R.id.save_btn_item);
        cancel = findViewById(R.id.cancel_btn_item);

        item_name = findViewById(R.id.ET_item_name);
        item_description = findViewById(R.id.ET_item_description);

        item_image = findViewById(R.id.item_image);

        Intent intent = getIntent();
        position = Integer.parseInt(intent.getExtras().getString("position"));
        String name = intent.getStringExtra("item_name");
        String description = intent.getStringExtra("description");

        byte[] byteArray = getIntent().getByteArrayExtra("image");
        image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        item_name.setText(name);
        item_description.setText(description);
        item_image.setImageBitmap(image);

        item_image.setOnClickListener(this);
        item_image.setOnLongClickListener(this);

        save.setOnClickListener(this);
        cancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (save == view)//option 2 - save the data and go to first screen
        {
            if (item_name.getText().toString().length() > 0 && item_description.getText().toString().length() > 0) {
                Intent intent = new Intent();
                intent.putExtra("position", String.valueOf(position));
                intent.putExtra("item_name", item_name.getText().toString());
                intent.putExtra("description", item_description.getText().toString());

                if(selectedImageUri == null){
                    if(!deleted){
                        message = "not changed";
                    }
                    intent.putExtra("image", message);
                }
                else{
                    intent.putExtra("image", selectedImageUri.toString());
                }

                setResult(RESULT_OK, intent);
                finish();
            }
        } else if (cancel == view) {
            setResult(RESULT_CANCELED, null);
            finish();
        }
        else if(view == item_image){
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Select Picture"), 1);
            }
            else{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                }
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 0){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Select Picture"), 1);
            }
            else {
                Toast.makeText(this, "Permission denied, you can change it in the settings tab", Toast.LENGTH_LONG).show();
            }
            return;
        }
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    try {
                        bitmap =  MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                        item_image.setImageBitmap(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public boolean onLongClick(View view) {
        if(view == item_image){
            createDeleteDialog();
        }
        return true;
    }
    public void createDeleteDialog() {
        d = new Dialog(this);
        d.setTitle("Are you sure you want to delete this image?");
        d.setContentView(R.layout.delete_friend_layout);
        TextView title = d.findViewById(R.id.TV_title);
        Button cancel = (Button) d.findViewById(R.id.cancel);
        Button delete = (Button) d.findViewById(R.id.remove);
        title.setText("Are you sure you want to delete this image?");
        delete.setText("Delete");
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                item_image.setImageBitmap(getBitmap(R.drawable.default_item_image, edit_item_activity.this));
                selectedImageUri = null;
                deleted = true;
                message = "deleted";
                d.dismiss();
            }
        });
        d.show();
    }
    private Bitmap getBitmap(int drawableRes, Context context) {
        Drawable drawable = context.getResources().getDrawable(drawableRes);
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }
}