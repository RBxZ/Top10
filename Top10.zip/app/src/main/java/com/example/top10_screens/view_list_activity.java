package com.example.top10_screens;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class view_list_activity extends AppCompatActivity implements View.OnClickListener {

    Button back, edit, comments;
    TextView list_name, list_description;
    ListView list_view;
    ArrayList<item_in_list> arrayList;
    ItemsAdapter itemsAdapter;
    item_in_list last;
    boolean isFriend = false;
    boolean[] changed = new boolean[10];
    Bitmap list_image;
    String list_format;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list);

        list_name = findViewById(R.id.TV_list_name);
        list_description = findViewById(R.id.TV_description);
        back = findViewById(R.id.back_btn);
        edit = findViewById(R.id.edit_list_btn);
        comments = findViewById(R.id.comments_btn);

        back.setOnClickListener(this);
        edit.setOnClickListener(this);
        comments.setOnClickListener(this);

        arrayList = new ArrayList<item_in_list>();
        Intent intent = getIntent();

        if(intent.getExtras().getString("purpose").equals("friend")){
            edit.setClickable(false);
            edit.setVisibility(View.INVISIBLE);
            isFriend = true;
        }

        String name_of_list = intent.getStringExtra("list_name");
        String description_of_list = intent.getStringExtra("list_description");
        list_name.setText(name_of_list);
        list_description.setText(description_of_list);
        byte[] byteArray = intent.getByteArrayExtra("list_image");
        list_image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        list_format = intent.getExtras().getString("list_format");
        for(int i=0; i<10; i++){
            String current_name = "item_name" + String.valueOf(i);
            String current_description = "item_description" + String.valueOf(i);
            String current_image = "item_image" + String.valueOf(i);
            String current_format = "format" + String.valueOf(i);
            String name_of_item = intent.getStringExtra(current_name);
            String description_of_item = intent.getStringExtra(current_description);
            String format_of_item = intent.getExtras().getString(current_format);
            item_in_list item = new item_in_list(name_of_item, description_of_item, this);
            if(format_of_item.equals("jpg")){
                item.setChanged(true);
                changed[i] = true;
            }
            else{
                changed[i] = false;
            }
            byte[] byteArray2 = intent.getByteArrayExtra(current_image);
            Bitmap image = BitmapFactory.decodeByteArray(byteArray2, 0, byteArray2.length);
            item.setImage(image);
            arrayList.add(item);
        }

        itemsAdapter = new ItemsAdapter(this, 0, 0, arrayList);
        list_view = findViewById(R.id.items_listview);
        list_view.setAdapter(itemsAdapter);

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                last = itemsAdapter.getItem(i);
                Intent intent = new Intent(view_list_activity.this, view_item_activity.class);
                intent.putExtra("item_name", last.getItem_name());
                intent.putExtra("description", last.getDescription());
                intent.putExtra("position", String.valueOf(i));
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                Bitmap bitmap = last.getImage();
                if(changed[i]){
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 20, bStream);
                }
                else{
                    bitmap.compress(Bitmap.CompressFormat.PNG, 20, bStream);
                }
                byte[] byteArray = bStream.toByteArray();
                intent.putExtra("image", byteArray);

                startActivityForResult(intent,0);
            }
        });
    }

    @Override
    public void onClick(View view) {
        if(view == back){
            Intent intent = new Intent();
            int size = itemsAdapter.getCount();
            intent.putExtra("size", String.valueOf(size));
            intent.putExtra("list_name", list_name.getText().toString());
            intent.putExtra("list_description", list_description.getText().toString());
            ByteArrayOutputStream bStream2 = new ByteArrayOutputStream();
            if(list_format.equals("jpg")){
                list_image.compress(Bitmap.CompressFormat.JPEG, 20, bStream2);
            }
            else{
                list_image.compress(Bitmap.CompressFormat.PNG, 20, bStream2);
            }
            byte[] byteArray2 = bStream2.toByteArray();
            intent.putExtra("list_image", byteArray2);
            intent.putExtra("list_format", list_format);
            for(int i=0; i<size; i++){
                String current_name = "item_name" + String.valueOf(i);
                String current_description = "item_description" + String.valueOf(i);
                String current_image = "item_image" + String.valueOf(i);
                String current_format = "format" + String.valueOf(i);
                intent.putExtra(current_name, itemsAdapter.getItem(i).getItem_name());
                intent.putExtra(current_description, itemsAdapter.getItem(i).getDescription());
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                Bitmap bitmap = itemsAdapter.getItem(i).getImage();
                String format = "";
                if(changed[i]){
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bStream);
                    format = "jpg";
                }
                else{
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                    format = "png";
                }
                byte[] byteArray = bStream.toByteArray();
                intent.putExtra(current_image, byteArray);
                intent.putExtra(current_format, format);
            }
            setResult(RESULT_OK, intent);
            finish();
        }
        else if(view == edit){
            Intent intent = new Intent(view_list_activity.this, edit_list_activity.class);
            intent.putExtra("purpose", "edit");
            int size = itemsAdapter.getCount();
            intent.putExtra("size", String.valueOf(size));
            intent.putExtra("list_name", list_name.getText().toString());
            intent.putExtra("list_description", list_description.getText().toString());
            ByteArrayOutputStream bStream2 = new ByteArrayOutputStream();
            if(list_format.equals("jpg")){
                list_image.compress(Bitmap.CompressFormat.JPEG, 20, bStream2);
            }
            else{
                list_image.compress(Bitmap.CompressFormat.PNG, 20, bStream2);
            }
            byte[] byteArray2 = bStream2.toByteArray();
            intent.putExtra("list_image", byteArray2);
            intent.putExtra("list_format", list_format);
            for(int i=0; i<size; i++){
                String current_name = "item_name" + String.valueOf(i);
                String current_description = "item_description" + String.valueOf(i);
                String current_image = "item_image" + String.valueOf(i);
                String current_format = "format" + String.valueOf(i);
                intent.putExtra(current_name, itemsAdapter.getItem(i).getItem_name());
                intent.putExtra(current_description, itemsAdapter.getItem(i).getDescription());
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                Bitmap bitmap = itemsAdapter.getItem(i).getImage();
                String format = "";
                if(changed[i]){
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bStream);
                    format = "jpg";
                }
                else{
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                    format = "png";
                }
                byte[] byteArray = bStream.toByteArray();
                intent.putExtra(current_image, byteArray);
                intent.putExtra(current_format, format);
            }
            startActivityForResult(intent,0);
        }
        else if(view == comments){
            Intent intent = new Intent(this, view_comments.class);
            if(isFriend){
                intent.putExtra("purpose", "friend");
            }
            else{
                intent.putExtra("purpose", "view");
            }
            startActivity(intent);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==0)
        {
            if(resultCode==RESULT_OK)
            {
                String name_of_list = data.getExtras().getString("list_name");
                String description_of_list = data.getExtras().getString("list_description");
                list_name.setText(name_of_list);
                list_description.setText(description_of_list);
                int size = Integer.parseInt(data.getExtras().getString("size"));
                byte[] byteArray2 = data.getByteArrayExtra("list_image");
                list_image = BitmapFactory.decodeByteArray(byteArray2, 0, byteArray2.length);
                list_format = data.getExtras().getString("list_format");
                for(int i=0; i<size; i++){
                    String current_name = "item_name" + String.valueOf(i);
                    String current_description = "item_description" + String.valueOf(i);
                    String current_image = "item_image" + String.valueOf(i);
                    String current_format = "format" + String.valueOf(i);
                    String name_of_item = data.getExtras().getString(current_name);
                    String description_of_item = data.getExtras().getString(current_description);
                    String format_of_item = data.getExtras().getString(current_format);
                    if(format_of_item.equals("jpg")){
                        itemsAdapter.getItem(i).setChanged(true);
                        changed[i] = true;
                    }
                    else{
                        itemsAdapter.getItem(i).setChanged(false);
                        changed[i] = false;
                    }
                    byte[] byteArray = data.getByteArrayExtra(current_image);
                    Bitmap image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                    itemsAdapter.getItem(i).setImage(image);
                    itemsAdapter.getItem(i).setItem_name(name_of_item);
                    itemsAdapter.getItem(i).setDescription(description_of_item);
                }
                itemsAdapter.notifyDataSetChanged();
            }
        }
    }
}