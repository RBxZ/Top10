package com.example.top10_screens;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ItemsAdapter extends ArrayAdapter<item_in_list> {
    Context context;
    List<item_in_list> objects;

    public ItemsAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<item_in_list> objects) {
        super(context, resource, textViewResourceId, objects);
        this.objects = objects;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.item_layout, parent, false);

        ImageView ivItem = (ImageView) view.findViewById(R.id.item_image);
        TextView tvTitle = (TextView) view.findViewById(R.id.item_name);
        TextView tvDescription = (TextView) view.findViewById(R.id.item_description);
        item_in_list temp = objects.get(position);

        tvTitle.setText(String.valueOf(temp.getItem_name()));
        tvDescription.setText(temp.getDescription());
        ivItem.setImageBitmap(temp.getImage());
        return view;
    }
}
