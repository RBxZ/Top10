package com.example.top10_screens;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.io.*;
import androidx.fragment.app.Fragment;

import com.example.top10_screens.R;

public class settings extends Fragment implements View.OnClickListener {

    public settings(){
        // require a empty public constructor
    }

    Button edit_user, change_permissions;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_settings, container, false);
        inflater.inflate(R.layout.fragment_settings, container, false);

        edit_user = rootView.findViewById(R.id.user_details);
        change_permissions = rootView.findViewById(R.id.permissions);
        edit_user.setOnClickListener(this);
        change_permissions.setOnClickListener(this);


        return rootView;
    }

    @Override
    public void onClick(View view) {
        if(view == edit_user){
            Intent intent = new Intent(getActivity(), edit_user_details_activity.class);
            startActivityForResult(intent, 0);
        }
        if (view == change_permissions){
            Intent intent = new Intent(getActivity(), handle_permissions_activity.class);
            startActivityForResult(intent, 1);
        }
    }
}