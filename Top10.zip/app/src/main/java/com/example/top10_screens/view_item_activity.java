package com.example.top10_screens;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class view_item_activity extends AppCompatActivity implements View.OnClickListener {

    Button back;
    TextView item_name, item_description;
    ImageView item_image;
    int position;
    Bitmap image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_item);

        item_name = findViewById(R.id.TV_item_name);
        item_description = findViewById(R.id.TV_item_description);
        back = findViewById(R.id.back_btn_item);
        item_image = findViewById(R.id.item_image);

        Intent intent = getIntent();
        position = Integer.parseInt(intent.getExtras().getString("position"));
        String name = intent.getStringExtra("item_name");
        String description = intent.getStringExtra("description");

        byte[] byteArray = intent.getByteArrayExtra("image");
        image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        item_name.setText(name);
        item_description.setText(description);
        item_image.setImageBitmap(image);

        back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == back){
            finish();
        }
    }
}