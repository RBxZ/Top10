package com.example.top10_screens;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class comment_adapter extends ArrayAdapter<comment_class> {
    Context context;
    List<comment_class> objects;

    public comment_adapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<comment_class> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.comment_layout, parent, false);

        TextView tvTitle = (TextView) view.findViewById(R.id.title);
        TextView tvContent = (TextView) view.findViewById(R.id.content);
        comment_class temp = objects.get(position);

        tvTitle.setText(String.valueOf(temp.getTitle()));
        tvContent.setText(temp.getContent());

        return view;
    }
}
