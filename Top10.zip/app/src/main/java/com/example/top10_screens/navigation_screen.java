package com.example.top10_screens;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class navigation_screen extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    BottomNavigationView bottomNavigationView;
    Button sign_out;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_screen);

        bottomNavigationView = findViewById(R.id.bottom_navigation_view);

        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.my_page_item);

        sign_out = findViewById(R.id.sign_out_btn);
        sign_out.setOnClickListener(this);
    }
    my_page my_page = new my_page();
    explorer explorer = new explorer();
    friends friends = new friends();
    settings settings = new settings();


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.my_page_item:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, my_page).commit();
                return true;

            case R.id.explorer_item:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, explorer).commit();
                return true;

            case R.id.friends_item:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, friends).commit();
                return true;

            case R.id.settings_item:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, settings).commit();
                return true;
        }
        return false;
    }

    @Override
    public void onClick(View view) {
        if(view == sign_out){
            finish();
        }
    }
}